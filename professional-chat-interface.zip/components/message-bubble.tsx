"use client"

import { User, Bot } from "lucide-react"
import { cn } from "@/lib/utils"

interface MessageBubbleProps {
  message: string
  isUser: boolean
  timestamp?: string
}

export function MessageBubble({ message, isUser, timestamp }: MessageBubbleProps) {
  return (
    <div className={cn("flex gap-3 max-w-4xl mx-auto px-4 py-6", isUser ? "flex-row-reverse" : "flex-row")}>
      {/* Avatar */}
      <div
        className={cn(
          "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center",
          isUser ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400",
        )}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      {/* Message Content */}
      <div className={cn("flex-1 space-y-2", isUser ? "text-right" : "text-left")}>
        <div
          className={cn(
            "inline-block max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed",
            isUser
              ? "bg-blue-600 text-white rounded-br-md"
              : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-bl-md",
          )}
        >
          <div className="whitespace-pre-wrap break-words">{message}</div>
        </div>
        {timestamp && (
          <div className={cn("text-xs text-gray-500 dark:text-gray-400 px-2", isUser ? "text-right" : "text-left")}>
            {timestamp}
          </div>
        )}
      </div>
    </div>
  )
}
